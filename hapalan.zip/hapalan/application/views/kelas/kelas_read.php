<div class="content-wrapper">
        <section class="content">
            <div class="box">
    <body>
        <h2 style="margin-top:0px">Kelas Read</h2>
        <table class="table">
	    <tr><td>Nama Kelas</td><td><?php echo $nama_kelas; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('kelas') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
    </div>
    </section>
</div>