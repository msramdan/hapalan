<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-warning box-solid">

                    <div class="box-body">
                        <div class='row'>
                            <div class='col-md-9'>
                                <div style="padding-bottom: 10px;">       
        </div>
            </div>
            <div class=' col-md-3'>
                                </div>
                            </div>


                            <div class="row" style="margin-bottom: 10px">
                                <div class="col-md-4 text-center">
                                    <div style="margin-top: 8px" id="message">
                                        <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                                    </div>
                                </div>
                                <div class="col-md-1 text-right">
                                </div>
                                <div class="col-md-3 text-right">

                                </div>
                            </div>
                            <div class="box-body" style="overflow-x: scroll; ">
                                
                                <table class="table table-bordered" id="table3">
                                    <thead>
                                        <tr>
                                        <th>No</th>
                                        <th>NIS</th>
                                        <th>Nama Siswa</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    
                                    <?php
                                            foreach ($siswa_data as $siswa) {
                                            ?>
                                        <tr>
                                            <td><?php echo ++$start ?></td>
                                            <td><?php echo $siswa->nis ?></td>
                                            <td><?php echo $siswa->nama_siswa ?></td>
                                            <td>
                                                <button type="button" id="view_raport" class="btn btn-success"
                                                data-siswa_id="<?php echo $siswa->siswa_id ?>"
                                                data-toggle="modal" data-target="#exampleModal">
                                                    View Raport
                                                </button>
                                            </td>
                                        </tr>
                                    <?php
                                            }
                                    ?>
                                </table>
                    <br>
                            </div>
                        </div>
                    </div>
                </div>
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">View Rapor</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <form method="post"  action="<?= base_url() ?>laporan/nilai_read">
            <div class="modal-body">
                <div class="form-group">
                <input type="hidden" name="siswa_id" id="siswa_id" value="" class="form-control">
                                <label for="tanggal" class="control-label">Tahun Ajar</label>
                                <select name="tahun_ajaran_id" class="form-control" required="">
                                <option value="">-- Pilih -- </option>
                                <?php foreach ($tahunajaran_list as $key => $data) { ?>
                                        <option value="<?php echo $data->tahun_ajaran_id ?>"><?php echo $data->tahun_ajaran . ' | Semester ' . $data->semester ?></option>
                                <?php } ?>
                            </select>
                            

                              </div>
                              <!-- <input type="submit" class="btn btn-primary" value="Cetak" name="Cetak" /> -->
                              <button type="submit" class="btn btn-warning"><i class="fa fa-print"></i> Cetak</button>
                          </div>
            
            </form>
    </div>
  </div>
</div>


<script type="text/javascript">
    $(document).on('click','#view_raport',function(){
          $('#siswa_id').val($(this).data('siswa_id'))
          //data kaNaN ini dari data yang ada di button
        })
</script>