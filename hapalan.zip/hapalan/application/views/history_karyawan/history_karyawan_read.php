<div class="content-wrapper">
        <section class="content">
            <div class="box">
    <body>
        <h2 style="margin-top:0px">History_karyawan Read</h2>
        <table class="table">
	    <tr><td>Nama</td><td><?php echo $username; ?></td></tr>
	    <tr><td>Info</td><td><?php echo $info; ?></td></tr>
	    <tr><td>Tanggal</td><td><?php echo $tanggal; ?></td></tr>
	    <tr><td>User Agent</td><td><?php echo $user_agent; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('history_karyawan') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
    </div>
    </section>
</div>