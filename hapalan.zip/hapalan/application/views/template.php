<!doctype html>
<html lang="en">

<head>
  <title>Webs Apps</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <!-- VENDOR CSS -->
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/vendor/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/vendor/themify-icons/css/themify-icons.css">
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/vendor/pace/themes/orange/pace-theme-minimal.css">
  <!-- MAIN CSS -->
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/css/main.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/css/skins/sidebar-nav-darkgray.css" type="text/css">
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/css/skins/navbar3.css" type="text/css">
  <!-- FOR DEMO PURPOSES ONLY. You should/may remove this in your project -->
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/css/demo.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>admin/assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- ICONS -->
  <link rel="apple-touch-icon" sizes="76x76" href="<?= base_url() ?>admin/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" sizes="96x96" href="<?= base_url() ?>admin/assets/img/favicon.png">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
</head>

<body>
  <!-- WRAPPER -->
  <div id="wrapper">
    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div>

    <?php if ($this->session->flashdata('message')) : ?>

    <?php endif; ?>
    <!-- NAVBAR -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="brand">
        <a href="index.html">
          <strong style="color: white; font-size: 18px">Aplikasi HQ</strong>
        </a>
      </div>
      <div class="container-fluid">
        <div id="tour-fullwidth" class="navbar-btn">
          <button type="button" class="btn-toggle-fullwidth"><i class="ti-arrow-circle-left"></i></button>
        </div>
        <form class="navbar-form navbar-left search-form">
          <input type="text" value="" class="form-control" placeholder="Search dashboard...">
          <button type="button" class="btn btn-default"><i class="fa fa-search"></i></button>
        </form>
        <div id="navbar-menu">
          <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <img src="<?= base_url() ?>assets/img/default-user.png" alt="Avatar">
                <span><?= ucfirst($this->fungsi->user_login()->username) ?></span>
              </a>
              <ul class="dropdown-menu logged-user-menu">
                <li><a href="<?= site_url('profil') ?>"><i class="ti-user"></i> <span>My Profile</span></a></li>
                <li><a href="<?= site_url('auth/logout') ?>"><i class="ti-power-off"></i> <span>Logout</span></a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END NAVBAR -->
    <!-- LEFT SIDEBAR -->
    <div id="sidebar-nav" class="sidebar">
      <nav>
        <ul class="nav" id="sidebar-nav-menu">
          <li class="menu-group">Main</li>
          <li><a href="<?= base_url() ?>dashboard"><i class="ti-home"></i> <span class="title">Dashboard</span></a></li>
          <li class="panel">
            <?php if ($this->session->userdata()['level'] == '1') { ?>
              <a href="#master" data-toggle="collapse" data-parent="#sidebar-nav-menu" class="collapsed"><i class="ti-list"></i> <span class="title">Master Data</span> <i class="icon-submenu ti-angle-left"></i></a>
              <div id="master" class="collapse ">
                <ul class="submenu">
                  <li><a href="<?= base_url() ?>sekolah"">Data Sekolah</a></li>
                  <li><a href=" <?= base_url() ?>Guru"">Data Guru</a></li>
                  <li><a href=" <?= base_url() ?>Siswa"">Data Siswa</a></li>
                  <li><a href=" <?= base_url() ?>Kelas"">Data Kelas</a></li>
                  <li><a href=" <?= base_url() ?>tahunajaran"">Data Tahun Ajaran</a></li>
                </ul>
              </div>
          </li>
        <?php } ?>
        <li class=" panel">
                      <a href="#penilaian" data-toggle="collapse" data-parent="#sidebar-nav-menu" class="collapsed"><i class="ti-receipt"></i> <span class="title">Penilaian</span> <i class="icon-submenu ti-angle-left"></i></a>
                      <div id="penilaian" class="collapse ">
                        <ul class="submenu">
                          <li><a href="<?= base_url() ?>nilai">Nilai Harian</a></li>
                          <li><a href=" <?= base_url() ?>nilai/ujian">Nilai Ujian</a></li>
                          <li><a href=" <?= base_url() ?>nilai_sikap">Nilai Sikap</a></li>
                        </ul>
                      </div>
                  </li>
                  <?php if ($this->session->userdata()['level'] == '1') { ?>
                    <li class="panel">
                      <a href="#pengatur" data-toggle="collapse" data-parent="#sidebar-nav-menu" class="collapsed"><i class="fa fa-gear"></i> <span class="title">Pengaturan</span> <i class="icon-submenu ti-angle-left"></i></a>
                      <div id="pengatur" class="collapse ">
                        <ul class="submenu">
                          <li><a href="<?= base_url() ?>user"">Pengaturan User</a></li>
                  <li><a href=" <?= base_url() ?>user_role"">Pengaturan Level</a></li>
                          <li><a href="<?= base_url() ?>backup"">Backup Database</a></li>
                  <li><a href=" <?= base_url() ?>History_karyawan"">History Login</a></li>
                        </ul>
                      </div>
                    </li>
                  <?php } ?>
                  <?php if ($this->session->userdata()['level'] == '1' || $this->session->userdata()['level'] == '2') { ?>
                    <li><a href="<?= base_url() ?>laporan"><i class="ti-book"></i> <span class="title">Rapor Santri</span></a></li>
                  <?php } ?>
                </ul>
                <button type="button" class="btn-toggle-minified" title="Toggle Minified Menu"><i class="ti-arrows-horizontal"></i></button>
      </nav>
    </div>
    <!-- END LEFT SIDEBAR -->
    <!-- MAIN -->
    <div class="main">
      <!-- MAIN CONTENT -->
      <div class="main-content">
        <div class="content-heading clearfix">
          <div class="heading-left">
            <h1 class="page-title">Waktu Server</h1>
            <p class="page-subtitle">
              <script type="text/javascript">
                //fungsi displayTime yang dipanggil di bodyOnLoad dieksekusi tiap 1000ms = 1detik
                function tampilkanwaktu() {
                  //buat object date berdasarkan waktu saat ini
                  var waktu = new Date();
                  //ambil nilai jam, 
                  //tambahan script + "" supaya variable sh bertipe string sehingga bisa dihitung panjangnya : sh.length
                  var sh = waktu.getHours() + "";
                  //ambil nilai menit
                  var sm = waktu.getMinutes() + "";
                  //ambil nilai detik
                  var ss = waktu.getSeconds() + "";
                  //tampilkan jam:menit:detik dengan menambahkan angka 0 jika angkanya cuma satu digit (0-9)
                  document.getElementById("clock").innerHTML = (sh.length == 1 ? "0" + sh : sh) + ":" + (sm.length == 1 ? "0" + sm : sm) + ":" + (ss.length == 1 ? "0" + ss : ss);
                }
              </script>

              <body onload="tampilkanwaktu();setInterval('tampilkanwaktu()', 1000);">

                <span id="clock"></span>
                <?php
                $hari = date('l');
                /*$new = date('l, F d, Y', strtotime($Today));*/
                if ($hari == "Sunday") {
                  echo "Minggu";
                } elseif ($hari == "Monday") {
                  echo "Senin";
                } elseif ($hari == "Tuesday") {
                  echo "Selasa";
                } elseif ($hari == "Wednesday") {
                  echo "Rabu";
                } elseif ($hari == "Thursday") {
                  echo ("Kamis");
                } elseif ($hari == "Friday") {
                  echo "Jum'at";
                } elseif ($hari == "Saturday") {
                  echo "Sabtu";
                }
                ?>,
                <?php
                $tgl = date('d');
                echo $tgl;
                $bulan = date('F');
                if ($bulan == "January") {
                  echo " Januari ";
                } elseif ($bulan == "February") {
                  echo " Februari ";
                } elseif ($bulan == "March") {
                  echo " Maret ";
                } elseif ($bulan == "April") {
                  echo " April ";
                } elseif ($bulan == "May") {
                  echo " Mei ";
                } elseif ($bulan == "June") {
                  echo " Juni ";
                } elseif ($bulan == "July") {
                  echo " Juli ";
                } elseif ($bulan == "August") {
                  echo " Agustus ";
                } elseif ($bulan == "September") {
                  echo " September ";
                } elseif ($bulan == "October") {
                  echo " Oktober ";
                } elseif ($bulan == "November") {
                  echo " November ";
                } elseif ($bulan == "December") {
                  echo " Desember ";
                }
                $tahun = date('Y');
                echo $tahun;
                ?>
                </center>
            </p>
          </div>
        </div>
        <div class="container-fluid">
          <!-- OVERVIEW -->
          <div class="panel panel-headline">
            <div class="panel-body">
              <?php echo $contents ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- END MAIN -->
    <div class="clearfix"></div>
    <footer>
      <!--         <div class="container-fluid">
          <p class="copyright">&copy; 2017 <a href="https://www.themeineed.com/" target="_blank">Theme I Need</a>. All Rights Reserved.</p>
        </div> -->
    </footer>
  </div>
  <!-- END WRAPPER -->
  <!-- Javascript -->
  <script src="<?= base_url() ?>admin/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?= base_url() ?>admin/assets/vendor/pace/pace.min.js"></script>
  <script src="<?= base_url() ?>admin/assets/scripts/klorofilpro-common.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>admin/assets/js/sweetalert.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>admin/assets/js/sweetalert.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script> <!-- untuk sweet alret -->
  <script src="<?php echo base_url(); ?>admin/assets/js/dataflash.js"></script>
  <script src="<?= base_url() ?>admin/assets/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="<?= base_url() ?>admin/assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#table1').DataTable()
      $('#table2').DataTable()
      $('#table3').DataTable()
    })
  </script>
</body>

</html>