<div class="content-wrapper">
        <section class="content">
            <div class="box">
    <body>
        <h2 style="margin-top:0px">Nilai_sikap Read</h2>
        <table class="table">
	    <tr><td>Siswa</td><td><?php echo $siswa_id; ?></td></tr>
	    <tr><td>Tahun Ajar</td><td><?php echo $tahun_ajaran_id; ?></td></tr>
	    <tr><td>Predikat Adab Terhadap Al-Qur'an</td><td><?php echo $nilai_sikap1; ?></td></tr>
	    <tr><td>Predikat Adab Terhadap Guru</td><td><?php echo $nilai_sikap2; ?></td></tr>
	    <tr><td>Tertib dan Disiplin</td><td><?php echo $nilai_sikap3; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('nilai_sikap') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
    </div>
    </section>
</div>