    <section class="content">
      <?php $this->view('messages') ?>
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Data Nilai Sikap</h3>
        </div>
        <div class="box-body table-responsive">
          <table class="table table-bordered table-striped" id="table1">
            <?php if ($this->fungsi->user_login()->level != '4') { ?>
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Kelas</th>
                  <th>View Data Kelas</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1;
                foreach ($row as $key => $value) { ?>
                  <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $value->nama_kelas ?></td>
                    <td><a href="<?= site_url('nilai_sikap/data/' . $value->kelas_id) ?>" class="btn btn-success btn-xs"><i class="fa fa-eye"></i>View</a></td>
                  </tr>
                <?php
                } ?>
              </tbody>
            <?php } else if ($this->fungsi->user_login()->level == '4') { ?>
              <thead>
                <tr>
                  <th>No</th>
                                            <th>Siswa</th>
                                            <th>Tahun Ajar</th>
                                            <th>Predikat Adab Terhadap Al-Qur'an</th>
                                            <th>Predikat Adab Terhadap Guru</th>
                                            <th>Tertib dan Disiplin</th>
                                            <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1;
                foreach ($row as $key => $value) { ?>
                  <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $value->nama_siswa ?></td>
                    <td><?= $value->tahun_ajaran . ' | Semester ' . $value->semester ?></td>                    
                    <td><?= $value->nilai_sikap1 ?></td>
                    <td><?= $value->nilai_sikap1 ?></td>
                    <td><?= $value->nilai_sikap3 ?></td>
                    <td><a href="<?= site_url('nilai_sikap/read/' . $value->nilai_sikap_id) ?>" class="btn btn-success btn-xs"><i class="fa fa-eye"></i>View</a></td>
                  </tr>
                <?php } ?>
              </tbody>
            <?php } ?>
          </table>

        </div>

    </section>