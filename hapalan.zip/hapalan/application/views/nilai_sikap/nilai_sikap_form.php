<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA NILAI_SIKAP</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered'>        

	    <tr>
						<td width='200'>Siswa<?php echo form_error('siswa_id') ?></td>
						<td><select name="siswa_id" class="form-control">
								<option value="">-- Pilih -- </option>
								<?php foreach ($siswa_list as $key => $data) {
								?>
									<?php if ($data->siswa_id == $siswa_id) { ?>
										<option value="<?php echo $data->siswa_id ?>" selected><?php echo $data->nama_siswa ?></option>
									<?php } else { ?>
										<option value="<?php echo $data->siswa_id ?>"><?php echo $data->nama_siswa ?></option>
									<?php } ?>
								<?php } ?>
							</select></td>
					</tr>

					<?php if ($button=='Update') { ?>
						<tr>
						<td width='200'>Tahun Ajaran<?php echo form_error('tahun_ajaran_id') ?></td>
						<td>
							<input readonly="" type="text" class="form-control" value="<?php echo $tahun_ajaran; ?> Semester <?php echo $semester ?>" />
							<input type="hidden" class="form-control" name="tahun_ajaran_id" id="tahun_ajaran_id" placeholder="" value="<?php echo $tahun_ajaran_id; ?>" />
						</td>
					</tr>
					<?php }else{ ?>
						<tr>
						<td width='200'>Tahun Ajaran<?php echo form_error('tahun_ajaran_id') ?></td>
						<td><select name="tahun_ajaran_id" class="form-control">
								<option value="">-- Pilih -- </option>
								<?php foreach ($tahunajaran_list as $key => $data) {
								?>
									<?php if ($data->tahun_ajaran_id == $tahun_ajaran_id) { ?>
										<option value="<?php echo $data->tahun_ajaran_id ?>" selected><?php echo $data->tahun_ajaran . ' | Semester ' . $data->semester ?></option>
									<?php } else { ?>
										<option value="<?php echo $data->tahun_ajaran_id ?>"><?php echo $data->tahun_ajaran . ' | Semester ' . $data->semester ?></option>
									<?php } ?>
								<?php } ?>
							</select></td>
					</tr>

					<?php } ?>
	    

	    <tr><td width='200'>Predikat Adab Terhadap Al-Qur'an <?php echo form_error('nilai_sikap1') ?></td><td><input type="text" class="form-control" name="nilai_sikap1" id="nilai_sikap1" placeholder="Predikat Adab Terhadap Al-Qur'an" value="<?php echo $nilai_sikap1; ?>" /></td></tr>
	    <tr><td width='200'>Predikat Adab Terhadap Guru <?php echo form_error('nilai_sikap2') ?></td><td><input type="text" class="form-control" name="nilai_sikap2" id="nilai_sikap2" placeholder="Predikat Adab Terhadap Guru" value="<?php echo $nilai_sikap2; ?>" /></td></tr>
	    <tr><td width='200'>Tertib dan Disiplin <?php echo form_error('nilai_sikap3') ?></td><td><input type="text" class="form-control" name="nilai_sikap3" id="nilai_sikap3" placeholder="Tertib dan Disiplin" value="<?php echo $nilai_sikap3; ?>" /></td></tr>
	    <tr><td></td><td>
	    	<input type="hidden" name="kelas_id" value="<?php echo $kelas_id; ?>" />
	    	<input type="hidden" name="nilai_sikap_id" value="<?php echo $nilai_sikap_id; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('nilai_sikap/data/' .$kelas_id) ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>