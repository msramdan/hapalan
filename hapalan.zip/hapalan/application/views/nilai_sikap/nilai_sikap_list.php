<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-warning box-solid">

                    <div class="box-header">
                        <h3 class="box-title">KELOLA DATA NILAI SIKAP</h3>
                    </div>

                    <div class="box-body">
                        <div class='row'>
                            <div class='col-md-9'>
                                <div style="padding-bottom: 10px;">
                                <?php if ($this->session->userdata('level') != '1' || $this->session->userdata('level') != '3') {
                                    if ($this->session->userdata('level') == '1' || check_access_guru($kelas_id) == true) { ?>
        <?php echo anchor(site_url('nilai_sikap/create/' . $kelas_id), '<i class="fa fa-wpforms" aria-hidden="true"></i> Tambah Data', 'class="btn btn-danger btn-sm"');}

         } ?>
            
        </div>
            </div>

                            </div>
                            <form method="get">
                              <div style="display: inline-block; width:20%; margin: 0px 5px;" class="form-group">
                                <label for="tanggal" class="control-label">Tahun Ajar</label>
                                <select name="tahun_ajaran_id" class="form-control">
                                <option value="">-- Pilih -- </option>
                                <?php foreach ($tahunajaran_list as $key => $data) { ?>
                                        <option value="<?php echo $data->tahun_ajaran_id ?>"><?php echo $data->tahun_ajaran . ' | Semester ' . $data->semester ?></option>
                                <?php } ?>
                            </select>

                              </div>
                                <button class="btn btn-primary btn-tampil-laporan" type="submit" >Filter</button>
                                <?php if(isset($_GET['tahun_ajaran_id']) ){ ?>
                                    <?php echo anchor(site_url('nilai_sikap/data/' . $kelas_id), 'Reset', 'class="btn btn-warning"'); ?>

                                <?php } ?>                                                               
                            
                    </form><br>                          
                            </div>
                        </div>
                    </div>
                </div>
    </section>
    <section class="content">
        <div class="panel">
            <div class="panel-body">
                  <div class="row" style="margin-bottom: 10px">
                                <div class="col-md-4 text-center">
                                    <div style="margin-top: 8px" id="message">
                                        <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                                    </div>
                                </div>
                            </div>

                            <?php
                                    if(isset($_GET['tahun_ajaran_id'])){
                                    $tahun_ajaran_id = $_GET['tahun_ajaran_id'];

                                    $sql = "select nilai_sikap.*,siswa.nama_siswa,siswa.kelas_id,tahun_ajaran.tahun_ajaran,tahun_ajaran.semester from nilai_sikap
                                    join siswa on siswa.siswa_id=nilai_sikap.siswa_id
                                    join tahun_ajaran on tahun_ajaran.tahun_ajaran_id=nilai_sikap.tahun_ajaran_id
                                    WHERE kelas_id='$kelas_id' And nilai_sikap.tahun_ajaran_id='$tahun_ajaran_id'";
                                }else{
                                    $sql = "select nilai_sikap.*,siswa.nama_siswa,siswa.kelas_id,tahun_ajaran.tahun_ajaran,tahun_ajaran.semester from nilai_sikap
                                    join siswa on siswa.siswa_id=nilai_sikap.siswa_id
                                    join tahun_ajaran on tahun_ajaran.tahun_ajaran_id=nilai_sikap.tahun_ajaran_id
                                    where kelas_id='$kelas_id'";  
                                }

                                
                                    $data = $this->db->query($sql)->result_array();
                                    ?>
                            <div class="box-body" style="overflow-x: scroll; ">
                                <table class="table table-bordered table-hover" id="table3">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Siswa</th>
                                            <th>Tahun Ajar</th>
                                            <th>Predikat Adab Terhadap Al-Qur'an</th>
                                            <th>Predikat Adab Terhadap Guru</th>
                                            <th>Tertib dan Disiplin</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; foreach ($data as $list) :  ?>
                                        <tr>
                                            <td><?=$no++?></td>
                                            <td><?= $list['nama_siswa'] ?></td>
                                            <td><?= $list['tahun_ajaran'] ?> Semester <?= $list['semester'] ?> </td>
                                            <td><?= $list['nilai_sikap1'] ?></td>
                                            <td><?= $list['nilai_sikap2'] ?></td>
                                            <td><?= $list['nilai_sikap3'] ?></td>
                                            <td>
                                                <?php 
                                                // echo anchor(site_url('nilai_sikap/read/'.$list['nilai_sikap_id']),'<i class="fa fa-eye" aria-hidden="true"></i>','class="btn btn-success btn-sm"'); 
                                                // echo '  ';

                                                if ($this->session->userdata('level') != '1' || $this->session->userdata('level') != '3') {
                                                    if ($this->session->userdata('level') == '1' || check_access_guru($kelas_id) == true) {
                                                        echo anchor(site_url('nilai_sikap/update/'.$list['nilai_sikap_id'].'/'.$kelas_id),'<i class="fa fa-pencil-square-o" aria-hidden="true"></i>','class="btn btn-primary btn-sm"'); 
                                                echo '  '; 
                                                echo anchor(site_url('nilai_sikap/delete/'.$list['nilai_sikap_id'].'/'.$kelas_id),'<i class="fa fa-trash-o" aria-hidden="true"></i>',array('onclick' => "return confirm('Do you want delete this record')",'class'=>'btn btn-danger btn-sm'));
                                                    }
                                                }


                                                 
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                        
                                    </tbody>
                                    
                                </table>
            </div>
        </div>
    </section>
</div>



