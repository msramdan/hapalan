<div class="content-wrapper">
    <section class="content">
        <div class="box">

            <body>
                <h2 style="margin-top:0px">Guru Read</h2>
                <table class="table">
                    <tr>
                        <td>NIP</td>
                        <td><?php echo $nip; ?></td>
                    </tr>
                    <tr>
                        <td>Nama Guru</td>
                        <td><?php echo $nama_guru; ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><?php echo $jenis_kelamin; ?></td>
                    </tr>
                    <tr>
                        <td>No Hp</td>
                        <td><?php echo $no_hp; ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?php echo $alamat; ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="<?php echo site_url('guru') ?>" class="btn btn-default">Cancel</a></td>
                    </tr>
                </table>
            </body>
        </div>
    </section>
</div>