<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-warning box-solid">
                     <div class="box-header with-border">
              <h4 class="box-title">Tambah Akses Wali kelas Untuk Username : <b><?php echo $user['username'] ?></b> </h4>
            </div>   
        
        <div class="box-body">       
   
        <div class="row" style="margin-bottom: 10px">
            <div class="col-md-4 text-center">
                <div style="margin-top: 8px" id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-1 text-right">
            </div>
            <div class="col-md-3 text-right">
                
            </div>
        </div>
        <div class="box-body" style="overflow-x: scroll; ">
        <table class="table table-bordered" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
        <th>Nama Kelas</th>
        <th>Access</th>
            </tr><?php $no = 1;
            foreach ($kelas_data as $kelas)
            {
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?php echo $kelas->nama_kelas ?></td>
                    <td>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" <?= check_access_wali($user['user_id'],$kelas->kelas_id); ?>
                                    data-user_id="<?= $user['user_id']; ?>"
                                    data-kelas_id="<?= $kelas->kelas_id ?>">            
                        </div>
                    </td>
                </tr>
                <?php } ?>
        </table>
        </div>
                    </div>
            </div>
            </div>
    </section>
</div>

    <script type="text/javascript">
      $('.form-check-input').on('click', function() {
        const user_id = $(this).data('user_id');
        const kelas_id = $(this).data('kelas_id');
        $.ajax({
          url: "<?= base_url('user/changeaccess_wali'); ?>",
          type: "post",
          data: {
            user_id: user_id,
            kelas_id: kelas_id,
          },
          success: function() {
            document.location.href = "<?= base_url('user/akses_kelas_walikelas/') ?>" + user_id;
          }

        });

      })
    </script>