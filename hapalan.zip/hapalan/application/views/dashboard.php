
						<div class="row">
							  <div class="alert alert-success alert-dismissible">
							    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							    <marquee direction="left" scrollamount="4" align="center" font-size="50px"><h4>Selamat datang <?= ucfirst($this->fungsi->user_login()->username) ?> di aplikasi HQ (Hapalan Quran) - Contact 0838-7473-1480</h4></marquee>
							  </div>
						</div>
						 <center >
<div>
  <img style="width: 50%;height: auto;border-radius: 30%" src="<?php echo base_url(); ?>admin/assets/img/Tahfidz.jpg">
</div>
</center>