<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-warning box-solid">

                    <div class="box-header">
                        <h3 class="box-title">KELOLA DATA NILAI</h3>
                    </div>

                    <div class="box-body">
                        <div class='row'>
                            <div class='col-md-9'>
                                <div style="padding-bottom: 10px;">
                                    <?php if ($this->session->userdata('level') != '1' || $this->session->userdata('level') != '3') {
                                        if ($this->session->userdata('level') == '1' || check_access_guru($kelas_id) == true) { ?>
                                    <?php echo anchor(site_url('nilai_siswa/create/' . $kelas_id), '<i class="fa fa-wpforms" aria-hidden="true"></i> Tambah Data', 'class="btn btn-danger btn-sm"'); ?>
                                    <?php } } ?>
            
        </div>
            </div>
                            </div>
                            <form method="get">
                              <div style="display: inline-block; width:20%; margin: 0px 5px;" class="form-group">
                                <label for="tanggal" class="control-label">Tanggal Awal</label>
                                <input type="date" class="form-control" name="tanggal_awal" id="tanggal_awal" value=""
                                    <?php if(!isset($_GET['tanggal_awal']) && !isset($_GET['tanggal_akhir'])){ ?>
                                        required
                                    <?php } ?>  
                                 />
                              </div>
                              <div style="display: inline-block; width:5%; margin: 0px 5px; text-align:center;" class="form-group">
                                <label for="sd" class="control-label text-center">-</label>
                                <div class="input-group-prepend">
                                  <span name="sd" class="input-group-text">s.d</span>
                                </div>
                              </div>
                              <div style="width:20%; display: inline-block; margin: 0px 5px;" class="form-group">
                                <label for="tanggal2" class="control-label">Tanggal Akhir</label>
                                <input type="date" class="form-control" name="tanggal_akhir" id="tanggal_akhir" value=""
                                <?php if(!isset($_GET['tanggal_awal']) && !isset($_GET['tanggal_akhir'])){ ?>
                                        required
                                    <?php } ?> 
                                 />
                              </div>
                                <button class="btn btn-primary btn-tampil-laporan" type="submit" >Filter</button>
                                <?php if(isset($_GET['tanggal_awal']) && isset($_GET['tanggal_akhir'])){ ?>
                                    <?php echo anchor(site_url('nilai_siswa/index/' . $kelas_id), 'Reset', 'class="btn btn-warning"'); ?>

                                <?php } ?>                                                               
                            
                    </form><br>

                          
                            </div>
                        </div>
                    </div>
                </div>
    </section>
        <section class="content">
        <div class="panel">
            <div class="panel-body">
                <div class="row" style="margin-bottom: 10px">
                                <div class="col-md-4 text-center">
                                    <div style="margin-top: 8px" id="message">
                                        <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                                    </div>
                                </div>
                                <div class="col-md-1 text-right">
                                </div>
                                <div class="col-md-3 text-right">

                                </div>
                            </div>

                            <?php
                                    if(isset($_GET['tanggal_awal']) && isset($_GET['tanggal_akhir'])){
                                    $tgl1 = $_GET['tanggal_awal'];
                                    $tgl2 = $_GET['tanggal_akhir'];
                                    $sql = "select nilai.*,siswa.nama_siswa,siswa.kelas_id,sql1.surat_indonesia as nama_surat1, sql2.surat_indonesia as nama_surat2,tahun_ajaran.tahun_ajaran,tahun_ajaran.semester from nilai
                                    join siswa on siswa.siswa_id=nilai.siswa_id
                                    join surat as sql1 on sql1.surat_id=nilai.surat_id_mulai
                                    join surat as sql2 on sql2.surat_id=nilai.surat_id_selesai
                                    join tahun_ajaran on tahun_ajaran.tahun_ajaran_id=nilai.tahun_ajaran_id
                                    WHERE tanggal BETWEEN '$tgl1' AND '$tgl2' And kelas_id='$kelas_id' And tipe='1' ;

                                    "
                                    ;
                                }else{
                                    $sql = "select nilai.*,siswa.nama_siswa,siswa.kelas_id,sql1.surat_indonesia as nama_surat1, sql2.surat_indonesia as nama_surat2,tahun_ajaran.tahun_ajaran,tahun_ajaran.semester from nilai
                                    join siswa on siswa.siswa_id=nilai.siswa_id
                                    join surat as sql1 on sql1.surat_id=nilai.surat_id_mulai
                                    join surat as sql2 on sql2.surat_id=nilai.surat_id_selesai
                                    join tahun_ajaran on tahun_ajaran.tahun_ajaran_id=nilai.tahun_ajaran_id
                                    where kelas_id='$kelas_id' And tipe='1'
                                    "
                                    ;
                                }

                                    

                                    $data = $this->db->query($sql)->result_array();
                                    ?>
                            
                            <div class="box-body" style="overflow-x: scroll; ">
                                <table class="table table-bordered table-hover" id="table3">
                                    <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Siswa</th>
                                        <th>Surat Mulai</th>
                                        <th>Surat Selesai</th>
                                        <th>Ayat Mulai</th>
                                        <th>Ayat Selesai</th>
                                        <th>Nilai</th>
                                        <th>Tanggal</th>
                                        <th>Tahun Ajaran</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $no = 1; foreach ($data as $list) :  ?>
                                        <tr>
                                            <td><?=$no++?></td>
                                            <td><?= $list['nama_siswa'] ?></td>
                                            <td><?= $list['nama_surat1'] ?></td>
                                            <td><?= $list['nama_surat2'] ?></td>
                                            <td><?= $list['ayat_mulai'] ?></td>
                                            <td><?= $list['ayat_selesai'] ?></td>
                                            <td><?= $list['nilai'] ?></td>
                                            <td><?= $list['tanggal'] ?></td>
                                            <td><?= $list['tahun_ajaran'] ?> Semester <?= $list['semester'] ?> </td>
                                            <td>
                                                <?php
                                                echo anchor(site_url('nilai_siswa/read/' . $list['nilai_id'] . '/' . $kelas_id), '<i class="fa fa-eye" aria-hidden="true"></i>', 'class="btn btn-success btn-sm"');
                                                echo '  ';
                                                if ($this->session->userdata('level') != '1' || $this->session->userdata('level') != '3') {
                                                    if ($this->session->userdata('level') == '1' || check_access_guru($kelas_id) == true) {
                                                        echo anchor(site_url('nilai_siswa/update/' . $list['nilai_id'] . '/' . $kelas_id), '<i class="fa fa-pencil-square-o" aria-hidden="true"></i>', 'class="btn btn-primary btn-sm"');
                                                        echo '  ';
                                                        echo anchor(site_url('nilai_siswa/delete/' . $list['nilai_id'] . '/' . $kelas_id), '<i class="fa fa-trash-o" aria-hidden="true"></i>',array('onclick' => "return confirm('Do you want delete this record')",'class'=>'btn btn-danger btn-sm'));
                                                    }
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>

                                </table>
            </div>
        </div>
    </section>
</div>