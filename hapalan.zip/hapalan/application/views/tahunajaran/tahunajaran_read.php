<div class="content-wrapper">
    <section class="content">
        <div class="box">

            <body>
                <h2 style="margin-top:0px">Tahun Ajaran Read</h2>
                <table class="table">
                    <tr>
                        <td>Tahun Ajaran</td>
                        <td><?php echo $tahun_ajaran; ?></td>
                    </tr>
                    <tr>
                        <td>Semester</td>
                        <td><?php echo $semester; ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><a href="<?php echo site_url('tahunajaran') ?>" class="btn btn-default">Cancel</a></td>
                    </tr>
                </table>
            </body>
        </div>
    </section>
</div>