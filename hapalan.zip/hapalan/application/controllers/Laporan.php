<?php defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Laporan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        check_admin();
        $this->load->model('laporan_model');
        $this->load->model('kelas_model');
        $this->load->model('nilai_model');
        $this->load->model('siswa_model');
        $this->load->model('sekolah_model');
        $this->load->model('tahunajaran_model');
        $this->load->model('akses_kelas_guru_model');
        $this->load->model('akses_kelas_walikelas_model');
    }

    public function index()
    {
        if ($this->fungsi->user_login()->level == 1) {
            $data['row'] = $this->kelas_model->get_all();
        } else {
            if ($this->fungsi->user_login()->level == 2) {
                $data['row'] = $this->akses_kelas_walikelas_model->get_akses($this->fungsi->user_login()->user_id);
                // var_dump($data['row']);
                // die;
            } else if ($this->fungsi->user_login()->level == 3) {
                $data['row'] = $this->akses_kelas_guru_model->get_akses($this->fungsi->user_login()->user_id);
            } else if ($this->fungsi->user_login()->level == 4) {
                $siswa = $this->siswa_model->get_by_userid($this->fungsi->user_login()->user_id);
                $data['row'] = $this->nilai_model->akses_siswa($siswa->siswa_id);
            }
        }
        $this->template->load('template', 'laporan/nilai_data', $data);
    }

    public function siswa($kelas_id){

        $siswa = $this->siswa_model->get_all($kelas_id);
        $kelas = $this->kelas_model->get_all();

        $data = array(
            'siswa_data' => $siswa,
            'tahunajaran_list' => $this->tahunajaran_model->get_all(),
            'kelas_id' =>$kelas_id,
            'kelas' =>$kelas,
            'start' => 0,
        );
        $this->template->load('template', 'laporan/siswa', $data);

    }

    public function nilai_read()
    {
        $siswa = $this->siswa_model->get_by_id($this->input->post('siswa_id'));
        $sekolah = $this->sekolah_model->get();
        $siswa_id = $this->input->post('siswa_id');
        $tahun_ajaran_id = $this->input->post('tahun_ajaran_id');
        $sql = "select * from nilai_sikap where siswa_id='$siswa_id' And tahun_ajaran_id='$tahun_ajaran_id'";
        $data = $this->db->query($sql)->row_array();


        $this->db->select('nama_guru');
        $this->db->where('kelas_id', $siswa->kelas_id);
        $this->db->join('user', 'user.user_id = akses_kelas_walikelas.user_id', 'left');
        $this->db->join('guru', 'guru.user_id = user.user_id', 'left');
        $walikelas = $this->db->get('akses_kelas_walikelas')->row();

        header("Content-type: application/vnd.ms-word;charset=utf-8");
        header("Content-Disposition: attachment;Filename=laporan-nilai-" . $siswa->nama_siswa . ".doc");
        header("Pragma: no-cache");
        header("Expires: 0");

        $data = array(
            'siswa' => $siswa,
            'sekolah' => $sekolah,
            'walikelas' => $walikelas,
            'nilai_harian' => $this->laporan_model->nilai_harian($this->input->post('siswa_id'), $this->input->post('tahun_ajaran_id')),
            'nilai_ujian' => $this->laporan_model->nilai_ujian($this->input->post('siswa_id'), $this->input->post('tahun_ajaran_id')),
            'nilai_sikap' => $data,
            'tahun_ajaran' => $this->tahunajaran_model->get_by_id($this->input->post('tahun_ajaran_id')),
            'start' => 0
        );

        $this->load->view('laporan/nilai_read', $data);
    }
}
