<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Nilai_sikap extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Nilai_sikap_model');
        $this->load->model('Nilai_model');
        $this->load->model('kelas_model');
        $this->load->model('akses_kelas_guru_model');
        $this->load->model('akses_kelas_walikelas_model');
        $this->load->library('form_validation');

        $this->load->model('Siswa_model');
        $this->load->model('Tahunajaran_model');
    }

    public function index()
    {
        if ($this->fungsi->user_login()->level == 1) {
            $data['row'] = $this->kelas_model->get_all();
        } else {
            if ($this->fungsi->user_login()->level == 2) {
                $data['row'] = $this->akses_kelas_walikelas_model->get_akses($this->fungsi->user_login()->user_id);
            } else if ($this->fungsi->user_login()->level == 3) {
                $data['row'] = $this->akses_kelas_guru_model->get_akses($this->fungsi->user_login()->user_id);
            } else if ($this->fungsi->user_login()->level == 4) {
                $siswa = $this->Siswa_model->get_by_userid($this->fungsi->user_login()->user_id);
                $data['row'] = $this->Nilai_model->akses_siswa_sikap($siswa->siswa_id);
            }
        }
        $this->template->load('template', 'nilai_sikap/data', $data);
    }


     public function data($kelas_id){
        block_siswa();

                $data = array(
                    'tahunajaran_list' => $this->Tahunajaran_model->get_all(),
                    'kelas_id' => $kelas_id
        );
        $this->template->load('template', 'nilai_sikap/nilai_sikap_list', $data);

    }

    public function read($id) 
    {
        $row = $this->Nilai_sikap_model->get_by_id($id);
        if ($row) {
            $data = array(
		'nilai_sikap_id' => $row->nilai_sikap_id,
		'siswa_id' => $row->nama_siswa,
		'tahun_ajaran_id' => $row->tahun_ajaran,
		'nilai_sikap1' => $row->nilai_sikap1,
		'nilai_sikap2' => $row->nilai_sikap2,
		'nilai_sikap3' => $row->nilai_sikap3,
	    );
            $this->template->load('template','nilai_sikap/nilai_sikap_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('nilai_sikap'));
        }
    }

    public function create($kelas_id) 
    {
        block_siswa();
        if ($this->session->userdata('level') == '2') {
            check_access_walikelas($kelas_id);
        } else if ($this->session->userdata('level') == '3') {
            check_access_guru($kelas_id);
        }

        $siswa = $this->Siswa_model->get_all($kelas_id);
        $tahunajaran = $this->Tahunajaran_model->get_all();

        $data = array(
            'button' => 'Create',
            'siswa_list' => $siswa,
            'tahunajaran_list' => $tahunajaran,
            'action' => site_url('nilai_sikap/create_action'),
	    'nilai_sikap_id' => set_value('nilai_sikap_id'),
	    'siswa_id' => set_value('siswa_id'),
	    'tahun_ajaran_id' => set_value('tahun_ajaran_id'),
	    'nilai_sikap1' => set_value('nilai_sikap1'),
	    'nilai_sikap2' => set_value('nilai_sikap2'),
	    'nilai_sikap3' => set_value('nilai_sikap3'),
        'kelas_id' => $kelas_id
	);
        $this->template->load('template','nilai_sikap/nilai_sikap_form', $data);
    }
    
    public function create_action() 
    {
        block_siswa();
        $kelas_id = $this->input->post('kelas_id');
        $tahun_ajaran_id = $this->input->post('tahun_ajaran_id');
        $siswa_id = $this->input->post('siswa_id');
        $sql = "select * from nilai_sikap where siswa_id='$siswa_id' And tahun_ajaran_id='$tahun_ajaran_id'";
        $data = $this->db->query($sql)->num_rows();
        if ($data >0) {
            echo "<script>
          alert('Sudah ada record data');
          window.location='" . site_url('nilai_sikap/data/' .$kelas_id) . "'</script>";
        }else{
        $this->_rules();
        if ($this->form_validation->run() == FALSE) {
            $this->create($kelas_id);
        } else {
            $data = array(
        'siswa_id' => $this->input->post('siswa_id',TRUE),
        'tahun_ajaran_id' => $this->input->post('tahun_ajaran_id',TRUE),
        'nilai_sikap1' => $this->input->post('nilai_sikap1',TRUE),
        'nilai_sikap2' => $this->input->post('nilai_sikap2',TRUE),
        'nilai_sikap3' => $this->input->post('nilai_sikap3',TRUE),
        );

            $this->Nilai_sikap_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('nilai_sikap/data/' .$kelas_id));
        }

        }
        
    }
    
    public function update($id , $kelas_id) 
    {
        block_siswa();
        $row = $this->Nilai_sikap_model->get_by_id($id);
        if ($this->session->userdata('level') == '2') {
            check_access_walikelas($kelas_id);
        } else if ($this->session->userdata('level') == '3') {
            check_access_guru($kelas_id);
        }

        $siswa = $this->Siswa_model->get_all($kelas_id);
        $tahunajaran = $this->Tahunajaran_model->get_all();


        if ($row) {
            $sql = "select * from tahun_ajaran where tahun_ajaran_id='$row->tahun_ajaran_id'";
            $hasil = $this->db->query($sql)->row_array();

            $data = array(
                'button' => 'Update',
                'kelas_id' => $kelas_id,
                'tahun_ajaran' =>$hasil['tahun_ajaran'],
                'semester' =>$hasil['semester'],
                'siswa_list' => $siswa,
            'tahunajaran_list' => $tahunajaran,
                'action' => site_url('nilai_sikap/update_action'),
		'nilai_sikap_id' => set_value('nilai_sikap_id', $row->nilai_sikap_id),
		'siswa_id' => set_value('siswa_id', $row->siswa_id),
		'tahun_ajaran_id' => set_value('tahun_ajaran_id', $row->tahun_ajaran_id),
		'nilai_sikap1' => set_value('nilai_sikap1', $row->nilai_sikap1),
		'nilai_sikap2' => set_value('nilai_sikap2', $row->nilai_sikap2),
		'nilai_sikap3' => set_value('nilai_sikap3', $row->nilai_sikap3),
	    );
            $this->template->load('template','nilai_sikap/nilai_sikap_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('nilai_sikap/data/' .$kelas_id));
        }
    }
    
    public function update_action() 
    {
        block_siswa();
        $this->_rules();
        $kelas_id = $this->input->post('kelas_id');

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('nilai_sikap_id', TRUE));
        } else {
            $data = array(
		'siswa_id' => $this->input->post('siswa_id',TRUE),
		'tahun_ajaran_id' => $this->input->post('tahun_ajaran_id',TRUE),
		'nilai_sikap1' => $this->input->post('nilai_sikap1',TRUE),
		'nilai_sikap2' => $this->input->post('nilai_sikap2',TRUE),
		'nilai_sikap3' => $this->input->post('nilai_sikap3',TRUE),
	    );

            $this->Nilai_sikap_model->update($this->input->post('nilai_sikap_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('nilai_sikap/data/' . $kelas_id));
        }
    }
    
    public function delete($id , $kelas_id) 
    {
        block_siswa();
        $row = $this->Nilai_sikap_model->get_by_id($id);

        if ($row) {
            $this->Nilai_sikap_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('nilai_sikap/data/' .$kelas_id));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('nilai_sikap/data/' .$kelas_id));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('siswa_id', 'siswa id', 'trim|required');
	$this->form_validation->set_rules('tahun_ajaran_id', 'tahun ajar id', 'trim|required');
	$this->form_validation->set_rules('nilai_sikap1', 'nilai sikap1', 'trim|required');
	$this->form_validation->set_rules('nilai_sikap2', 'nilai sikap2', 'trim|required');
	$this->form_validation->set_rules('nilai_sikap3', 'nilai sikap3', 'trim|required');

	$this->form_validation->set_rules('nilai_sikap_id', 'nilai_sikap_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "nilai_sikap.xls";
        $judul = "nilai_sikap";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Siswa Id");
	xlsWriteLabel($tablehead, $kolomhead++, "Tahun Ajar Id");
	xlsWriteLabel($tablehead, $kolomhead++, "Nilai Sikap1");
	xlsWriteLabel($tablehead, $kolomhead++, "Nilai Sikap2");
	xlsWriteLabel($tablehead, $kolomhead++, "Nilai Sikap3");

	foreach ($this->Nilai_sikap_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteNumber($tablebody, $kolombody++, $data->siswa_id);
	    xlsWriteNumber($tablebody, $kolombody++, $data->tahun_ajaran_id);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nilai_sikap1);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nilai_sikap2);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nilai_sikap3);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=nilai_sikap.doc");

        $data = array(
            'nilai_sikap_data' => $this->Nilai_sikap_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('nilai_sikap/nilai_sikap_doc',$data);
    }

}

/* End of file Nilai_sikap.php */
/* Location: ./application/controllers/Nilai_sikap.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2021-08-11 05:51:40 */
/* http://harviacode.com */